# House Rental System ASP.net
This is the project for House Rental System in C# ASP.NET and MSSQL Server.



## Pre-requisities

1. You should have installed MS SQL Server Database on your PC
2. You should have installed Microsoft Visual Studio IDE

## Instructions to Use Locally
1. Download or Clone this project
2. Import database from the project into your MS SQL SERVER
3. Go to web.config file and add your own connection string or connection to database.
If your database is connected then you must be good to go.
4. Open the project on Microsoft Visual Studio, then click on run.
